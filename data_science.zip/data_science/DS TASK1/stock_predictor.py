import yfinance as yf
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
import matplotlib.pyplot as plt

def download_stock_data(ticker, start_date, end_date):
    stock_data = yf.download(ticker, start=start_date, end=end_date)
    return stock_data

def prepare_lstm_data(data, n_steps):
    X, y = [], []
    for i in range(len(data)-n_steps):
        X.append(data[i:(i+n_steps), 0])
        y.append(data[i + n_steps, 0])
    return np.array(X), np.array(y)

np.random.seed(42)

ticker = 'AAPL'
start_date = '2010-01-01'
end_date = '2021-12-31'
n_steps = 60  
epochs = 50
batch_size = 32

stock_data = download_stock_data(ticker, start_date, end_date)

data = stock_data['Close'].values.reshape(-1, 1)

scaler = MinMaxScaler(feature_range=(0, 1))
data_scaled = scaler.fit_transform(data)

X, y = prepare_lstm_data(data_scaled, n_steps)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=False)

X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))
X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))

model = Sequential()
model.add(LSTM(units=50, activation='relu', input_shape=(n_steps, 1)))
model.add(Dense(units=1))
model.compile(optimizer='adam', loss='mean_squared_error')

model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=2)

train_predict = model.predict(X_train)
test_predict = model.predict(X_test)

train_predict = scaler.inverse_transform(train_predict)
test_predict = scaler.inverse_transform(test_predict)

train_plot = np.empty_like(data_scaled)
train_plot[:, :] = np.nan
train_plot[n_steps:len(train_predict) + n_steps, :] = train_predict

test_plot = np.empty_like(data_scaled)
test_plot[:, :] = np.nan

start_index = len(train_predict) + (n_steps * 2)
end_index = start_index + len(test_predict)

if end_index <= len(data_scaled):
    test_plot[start_index:end_index, :] = test_predict
else:
    test_plot[start_index:, :] = test_predict[:len(data_scaled) - start_index, :]


plt.figure(figsize=(14, 7))
plt.plot(scaler.inverse_transform(data_scaled), label='Actual Stock Price')
plt.plot(train_plot, label='Train Predictions')
plt.plot(test_plot, label='Test Predictions')
plt.title('Stock Price Prediction using LSTM')
plt.xlabel('Time')
plt.ylabel('Stock Price')
plt.legend()
plt.show()

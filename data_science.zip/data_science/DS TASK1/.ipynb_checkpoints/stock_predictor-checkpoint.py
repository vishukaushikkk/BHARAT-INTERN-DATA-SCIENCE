# Install the required libraries
!pip install yfinance pandas numpy scikit-learn matplotlib tensorflow

# Import necessary libraries
import yfinance as yf
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
import matplotlib.pyplot as plt

# Function to download stock data
def download_stock_data(ticker, start_date, end_date):
    stock_data = yf.download(ticker, start=start_date, end=end_date)
    return stock_data

# Function to prepare data for LSTM
def prepare_lstm_data(data, n_steps):
    X, y = [], []
    for i in range(len(data)-n_steps):
        X.append(data[i:(i+n_steps), 0])
        y.append(data[i + n_steps, 0])
    return np.array(X), np.array(y)

# Set the seed for reproducibility
np.random.seed(42)

# Define parameters
ticker = 'AAPL'
start_date = '2010-01-01'
end_date = '2021-12-31'
n_steps = 60  # Number of time steps for LSTM
epochs = 50
batch_size = 32

# Download stock data
stock_data = download_stock_data(ticker, start_date, end_date)

# Extract 'Close' prices
data = stock_data['Close'].values.reshape(-1, 1)

# Normalize data
scaler = MinMaxScaler(feature_range=(0, 1))
data_scaled = scaler.fit_transform(data)

# Prepare data for LSTM
X, y = prepare_lstm_data(data_scaled, n_steps)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=False)

# Reshape input data to be 3D [samples, timesteps, features]
X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))
X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))

# Build the LSTM model
model = Sequential()
model.add(LSTM(units=50, activation='relu', input_shape=(n_steps, 1)))
model.add(Dense(units=1))
model.compile(optimizer='adam', loss='mean_squared_error')

# Train the model
model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=2)

# Make predictions
train_predict = model.predict(X_train)
test_predict = model.predict(X_test)

# Transform predictions back to original scale
train_predict = scaler.inverse_transform(train_predict)
test_predict = scaler.inverse_transform(test_predict)

# Plotting the results
train_plot = np.empty_like(data_scaled)
train_plot[:, :] = np.nan
train_plot[n_steps:len(train_predict) + n_steps, :] = train_predict

test_plot = np.empty_like(data_scaled)
test_plot[:, :] = np.nan
test_plot[len(train_predict) + (n_steps * 2):len(data_scaled), :] = test_predict

plt.figure(figsize=(14, 7))
plt.plot(scaler.inverse_transform(data_scaled), label='Actual Stock Price')
plt.plot(train_plot, label='Train Predictions')
plt.plot(test_plot, label='Test Predictions')
plt.title('Stock Price Prediction using LSTM')
plt.xlabel('Time')
plt.ylabel('Stock Price')
plt.legend()
plt.show()

from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from tensorflow.keras.preprocessing.image import img_to_array
import numpy as np

model = load_model('mnist_model.h5')

def load_your_image(file_path):
    img = image.load_img(file_path, color_mode='grayscale', target_size=(28, 28))
    
    img_array = img_to_array(img)
    
    img_array = img_array / 255.0
    
    img_array = np.reshape(img_array, (1, 28, 28, 1))
    
    return img_array

new_image = load_your_image('path/to/your/image.jpg')  #Replace with user input

predictions = model.predict(new_image)

predicted_digit = np.argmax(predictions)

print(f'The model predicts that the digit is: {predicted_digit}')
